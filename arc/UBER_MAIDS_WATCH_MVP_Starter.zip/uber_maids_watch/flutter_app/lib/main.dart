import 'package:flutter/material.dart';
import 'features/home_screen.dart';
void main() => runApp(const UberMaidsApp());
class UberMaidsApp extends StatelessWidget {
  const UberMaidsApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'UBER MAIDS WATCH', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6A1B9A)), useMaterial3: true),
    home: const HomeScreen());
}
