class ApiConfig {
  // Android emulator: 10.0.2.2. Physical phone: use your computer's LAN IP.
  static const String apiBaseUrl = 'http://10.0.2.2:8000/api';
}
