import 'package:flutter/material.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('UBER MAIDS WATCH')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text('Trusted help for your home', style: Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height: 8), const Text('Find household support, request a maid, or manage your work profile.'),
      const SizedBox(height: 24),
      _Tile('Family account','Register your household and request a maid.',Icons.home_outlined),
      _Tile('Maid registration','Submit your details for review and training.',Icons.person_outline),
      _Tile('Staff and administration','Manage applications, bookings and assignments.',Icons.admin_panel_settings_outlined),
      const SizedBox(height: 18), const Text('Starter interface only. Registration and dashboard flows still need to be connected to the API.',style: TextStyle(color: Colors.black54)),
    ]));
}
class _Tile extends StatelessWidget {
  final String title, subtitle; final IconData icon;
  const _Tile(this.title,this.subtitle,this.icon);
  @override Widget build(BuildContext context)=>Card(child:ListTile(leading:Icon(icon,size:30),title:Text(title),subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_right)));
}
