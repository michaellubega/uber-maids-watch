# UBER MAIDS WATCH — MVP starter

Flutter client + Django REST API for maid placement and supervision.

## Backend setup
1. Python 3.11+ recommended; create and activate a virtual environment.
2. `cd backend && pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and set PostgreSQL credentials.
4. `python manage.py makemigrations core && python manage.py migrate`
5. `python manage.py createsuperuser && python manage.py runserver`

API: `http://127.0.0.1:8000/api/`; admin: `/admin/`.

## Flutter setup
`cd flutter_app && flutter pub get && flutter run`.
Change `apiBaseUrl` in `lib/core/api_config.dart` for your emulator/device.

## Important
This is a development MVP foundation, not production-ready. Do not upload real ID documents or sensitive client information until object-level permissions, private document delivery, audit logging, tests and security review are completed. See `docs/BUSINESS_RULES.md` for financial rules still requiring Evelyn's confirmation.
