# Initial API routes

All routes are under `/api/`. Get JWT tokens from `POST /api/auth/token/`.
- `POST auth/register/` — create a basic account.
- `GET/POST maids/`, `families/`, `services/` — records and service catalog.
- `GET/POST bookings/` — family booking requests.
- `GET/POST assignments/`, `training-records/` — staff-managed operations.
- `GET/POST leave-requests/`, `replacement-requests/` — requests and review records.
- `GET/POST feedback/`, `payments/` — feedback and payment records.
- `GET dashboard/summary/` — management counts.

This is an initial contract. Add object-level permissions, field validation, pagination, audit logs, private file access and automated tests before production.
