# Business rules awaiting Evelyn's confirmation

| Item | Current understanding | Must be confirmed |
|---|---|---|
| UGX 150,000 | Mentioned as booking/service fee and monthly charge | One-time or recurring? |
| UGX 120,000 / UGX 30,000 | Maid and business shares were mentioned | Exact payment split and timing? |
| UGX 20,000 commitment savings | Mentioned separately | Additional or deducted from maid's share? Who holds it and when is it released? |
| Larger households | Price may increase with family size | Pricing factors and thresholds? |
| Two-week replacement | Free replacement guarantee described | Eligibility and exclusions? |
| Leave notice | Planned leave at least one week ahead | Calendar or working days? Emergency process? |
| Existing-maid supervision | UGX 150,000 monthly was mentioned | Included services and whether fee is per maid? |
| Multiple maids | System counts maids per household | Is each maid charged separately? |

Until confirmed, staff should record agreed quotes manually. Do not automate disputed calculations.
