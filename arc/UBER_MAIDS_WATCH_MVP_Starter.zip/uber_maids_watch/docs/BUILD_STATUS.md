# Build status

Included: Django project, custom user roles, core database models, JWT endpoints, REST viewsets, Django admin registration, dashboard summary endpoint, Flutter landing screen, setup notes and unresolved business rules.

Not yet complete: full Flutter registration/login and role-specific screens, complete object-level permissions, secure private ID document delivery, approval workflow actions, payment gateway integration, notifications, audit logs, automated tests, and production deployment.

Do not enter real ID documents or sensitive family data until access controls and private media handling have been reviewed.
