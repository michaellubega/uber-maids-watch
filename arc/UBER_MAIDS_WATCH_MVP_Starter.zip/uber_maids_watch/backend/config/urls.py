from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from core.views import *
router = DefaultRouter()
for prefix, view in [('maids',MaidViewSet),('families',FamilyViewSet),('services',ServiceViewSet),('bookings',BookingViewSet),('assignments',AssignmentViewSet),('training-records',TrainingRecordViewSet),('leave-requests',LeaveRequestViewSet),('replacement-requests',ReplacementRequestViewSet),('feedback',FeedbackViewSet),('payments',PaymentViewSet)]: router.register(prefix, view, basename=prefix)
urlpatterns = [path('admin/',admin.site.urls),path('api/auth/register/',RegisterView.as_view()),path('api/auth/token/',TokenObtainPairView.as_view()),path('api/auth/token/refresh/',TokenRefreshView.as_view()),path('api/dashboard/summary/',dashboard_summary),path('api/',include(router.urls))]
