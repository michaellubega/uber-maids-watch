from django.contrib.auth import get_user_model
from rest_framework import serializers
from .models import *
User=get_user_model()
class RegisterSerializer(serializers.ModelSerializer):
    password=serializers.CharField(write_only=True,min_length=8)
    class Meta:
        model=User; fields=('id','username','first_name','last_name','email','phone_number','password')
    def create(self,data):
        password=data.pop('password'); user=User(**data); user.set_password(password); user.save(); return user
class ModelSerializerBase(serializers.ModelSerializer):
    class Meta: fields='__all__'
class MaidSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=MaidProfile
class FamilySerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=FamilyProfile
class ServiceSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=Service
class BookingSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=Booking; read_only_fields=('family','status','quoted_amount_ugx')
class AssignmentSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=Assignment
class TrainingSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=TrainingRecord
class LeaveSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=LeaveRequest; read_only_fields=('maid','status','reviewed_by')
class ReplacementSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=ReplacementRequest; read_only_fields=('family','status')
class FeedbackSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=Feedback; read_only_fields=('author',)
class PaymentSerializer(ModelSerializerBase):
    class Meta(ModelSerializerBase.Meta): model=Payment
