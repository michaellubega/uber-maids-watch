from django.contrib.auth import get_user_model
from rest_framework import viewsets, generics
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from .models import *
from .serializers import *
User=get_user_model()
class RegisterView(generics.CreateAPIView):
    serializer_class=RegisterSerializer; permission_classes=[AllowAny]
class AdminViewSet(viewsets.ModelViewSet):
    permission_classes=[IsAuthenticated]
    def check_admin(self):
        if self.request.user.role not in ('ADMIN','STAFF'): from rest_framework.exceptions import PermissionDenied; raise PermissionDenied('Staff access required.')
    def perform_create(self,serializer): self.check_admin(); serializer.save()
    def perform_update(self,serializer): self.check_admin(); serializer.save()
    def perform_destroy(self,instance): self.check_admin(); instance.delete()
class MaidViewSet(AdminViewSet): queryset=MaidProfile.objects.select_related('user').all(); serializer_class=MaidSerializer
class FamilyViewSet(AdminViewSet): queryset=FamilyProfile.objects.select_related('user').all(); serializer_class=FamilySerializer
class ServiceViewSet(AdminViewSet): queryset=Service.objects.filter(active=True); serializer_class=ServiceSerializer
class BookingViewSet(viewsets.ModelViewSet):
    serializer_class=BookingSerializer
    def get_queryset(self):
        q=Booking.objects.select_related('family__user','service')
        return q if self.request.user.role in ('ADMIN','STAFF') else q.filter(family__user=self.request.user)
    def perform_create(self,s): s.save(family=FamilyProfile.objects.get(user=self.request.user))
class AssignmentViewSet(AdminViewSet): queryset=Assignment.objects.select_related('family','maid').all(); serializer_class=AssignmentSerializer
class TrainingRecordViewSet(AdminViewSet): queryset=TrainingRecord.objects.select_related('maid').all(); serializer_class=TrainingSerializer
class LeaveRequestViewSet(viewsets.ModelViewSet):
    serializer_class=LeaveSerializer
    def get_queryset(self):
        q=LeaveRequest.objects.select_related('maid__user')
        return q if self.request.user.role in ('ADMIN','STAFF') else q.filter(maid__user=self.request.user)
    def perform_create(self,s): s.save(maid=MaidProfile.objects.get(user=self.request.user))
class ReplacementRequestViewSet(viewsets.ModelViewSet):
    serializer_class=ReplacementSerializer
    def get_queryset(self):
        q=ReplacementRequest.objects.select_related('family__user')
        return q if self.request.user.role in ('ADMIN','STAFF') else q.filter(family__user=self.request.user)
    def perform_create(self,s): s.save(family=FamilyProfile.objects.get(user=self.request.user))
class FeedbackViewSet(viewsets.ModelViewSet):
    queryset=Feedback.objects.all(); serializer_class=FeedbackSerializer
    def perform_create(self,s): s.save(author=self.request.user)
class PaymentViewSet(AdminViewSet): queryset=Payment.objects.select_related('family').all(); serializer_class=PaymentSerializer
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def dashboard_summary(request):
    if request.user.role not in ('ADMIN','STAFF'): return Response({'detail':'Staff access required'},status=403)
    return Response({'maids_total':MaidProfile.objects.count(),'maids_in_training':MaidProfile.objects.filter(status='IN_TRAINING').count(),'maids_available':MaidProfile.objects.filter(status='AVAILABLE').count(),'maids_at_work':MaidProfile.objects.filter(status='AT_WORK').count(),'families_total':FamilyProfile.objects.count(),'new_bookings':Booking.objects.filter(status='NEW').count(),'open_replacements':ReplacementRequest.objects.filter(status='OPEN').count(),'pending_leave':LeaveRequest.objects.filter(status='PENDING').count()})
