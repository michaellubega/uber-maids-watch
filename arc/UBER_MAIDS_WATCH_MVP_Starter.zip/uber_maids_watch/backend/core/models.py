from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings

class User(AbstractUser):
    role=models.CharField(max_length=12,choices=[('ADMIN','Administrator'),('STAFF','Staff'),('MAID','Maid'),('FAMILY','Family')],default='FAMILY')
    phone_number=models.CharField(max_length=25,blank=True)

class MaidProfile(models.Model):
    STATUS=[('APPLIED','Application received'),('IN_TRAINING','In training'),('TRAINED','Training completed'),('AVAILABLE','Available'),('AT_WORK','At work'),('HOLIDAY','On holiday'),('LEAVE','On leave'),('INACTIVE','Inactive')]
    user=models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='maid_profile')
    date_of_birth=models.DateField(null=True,blank=True)
    national_id_number=models.CharField(max_length=80,blank=True)
    national_id_document=models.FileField(upload_to='private/maid_ids/',blank=True)
    address=models.TextField(blank=True); skills=models.TextField(blank=True)
    experience_years=models.PositiveSmallIntegerField(default=0)
    status=models.CharField(max_length=15,choices=STATUS,default='APPLIED')
    verified=models.BooleanField(default=False)
    def __str__(self): return self.user.get_full_name() or self.user.username

class NextOfKin(models.Model):
    maid=models.ForeignKey(MaidProfile,on_delete=models.CASCADE,related_name='next_of_kin')
    full_name=models.CharField(max_length=160); relationship=models.CharField(max_length=80,blank=True)
    phone_number=models.CharField(max_length=25); address=models.TextField(blank=True)

class FamilyProfile(models.Model):
    user=models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='family_profile')
    household_location=models.CharField(max_length=255); number_of_rooms=models.PositiveSmallIntegerField(default=1)
    adults_count=models.PositiveSmallIntegerField(default=1); children_age_ranges=models.CharField(max_length=120,blank=True)
    has_washing_machine=models.BooleanField(default=False)
    preferred_maid_gender=models.CharField(max_length=10,choices=[('FEMALE','Female'),('MALE','Male'),('ANY','No preference')],default='ANY')
    household_notes=models.TextField(blank=True)

class Service(models.Model):
    name=models.CharField(max_length=120,unique=True); description=models.TextField(blank=True); active=models.BooleanField(default=True)
    display_price_ugx=models.PositiveIntegerField(null=True,blank=True)
    price_frequency=models.CharField(max_length=20,choices=[('ONE_TIME','One-time'),('MONTHLY','Monthly'),('QUOTE','Custom quote')],default='QUOTE')
    def __str__(self): return self.name

class Booking(models.Model):
    family=models.ForeignKey(FamilyProfile,on_delete=models.PROTECT,related_name='bookings'); service=models.ForeignKey(Service,on_delete=models.PROTECT)
    requested_start_date=models.DateField(null=True,blank=True); duties=models.TextField(blank=True)
    quoted_amount_ugx=models.PositiveIntegerField(null=True,blank=True)
    status=models.CharField(max_length=12,choices=[('NEW','New'),('REVIEWING','Under review'),('CONFIRMED','Confirmed'),('FULFILLED','Fulfilled'),('CANCELLED','Cancelled')],default='NEW')
    created_at=models.DateTimeField(auto_now_add=True)

class Assignment(models.Model):
    family=models.ForeignKey(FamilyProfile,on_delete=models.PROTECT,related_name='assignments'); maid=models.ForeignKey(MaidProfile,on_delete=models.PROTECT,related_name='assignments')
    booking=models.ForeignKey(Booking,on_delete=models.SET_NULL,null=True,blank=True)
    start_date=models.DateField(); end_date=models.DateField(null=True,blank=True); active=models.BooleanField(default=True); notes=models.TextField(blank=True)

class TrainingRecord(models.Model):
    maid=models.ForeignKey(MaidProfile,on_delete=models.CASCADE,related_name='training_records'); topic=models.CharField(max_length=160)
    trainer=models.CharField(max_length=160,blank=True); training_date=models.DateField(); completed=models.BooleanField(default=False); notes=models.TextField(blank=True)

class LeaveRequest(models.Model):
    maid=models.ForeignKey(MaidProfile,on_delete=models.PROTECT,related_name='leave_requests'); start_date=models.DateField(); end_date=models.DateField()
    reason=models.TextField(blank=True); emergency=models.BooleanField(default=False)
    status=models.CharField(max_length=10,choices=[('PENDING','Pending'),('APPROVED','Approved'),('DECLINED','Declined')],default='PENDING')
    reviewed_by=models.ForeignKey(settings.AUTH_USER_MODEL,null=True,blank=True,on_delete=models.SET_NULL)

class ReplacementRequest(models.Model):
    family=models.ForeignKey(FamilyProfile,on_delete=models.PROTECT,related_name='replacement_requests'); assignment=models.ForeignKey(Assignment,on_delete=models.PROTECT)
    reason=models.TextField(); status=models.CharField(max_length=10,choices=[('OPEN','Open'),('REVIEWING','Under review'),('RESOLVED','Resolved'),('REJECTED','Rejected')],default='OPEN')

class Feedback(models.Model):
    author=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='given_feedback')
    subject_user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='received_feedback')
    assignment=models.ForeignKey(Assignment,on_delete=models.PROTECT); rating=models.PositiveSmallIntegerField(); comments=models.TextField(blank=True)
    created_at=models.DateTimeField(auto_now_add=True)

class Payment(models.Model):
    family=models.ForeignKey(FamilyProfile,on_delete=models.PROTECT,related_name='payments'); assignment=models.ForeignKey(Assignment,null=True,blank=True,on_delete=models.SET_NULL)
    amount_ugx=models.PositiveIntegerField(); description=models.CharField(max_length=255); payment_method=models.CharField(max_length=30,blank=True)
    reference=models.CharField(max_length=100,blank=True); status=models.CharField(max_length=10,choices=[('PENDING','Pending'),('PAID','Paid'),('FAILED','Failed'),('REFUNDED','Refunded')],default='PENDING')
    paid_at=models.DateTimeField(null=True,blank=True); created_at=models.DateTimeField(auto_now_add=True)
