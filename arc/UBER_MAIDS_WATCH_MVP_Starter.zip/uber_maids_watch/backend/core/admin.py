from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import *
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets=UserAdmin.fieldsets+(('Business access',{'fields':('role','phone_number')}),)
    list_display=('username','email','role','phone_number','is_staff')
for model in [MaidProfile,NextOfKin,FamilyProfile,Service,Booking,Assignment,TrainingRecord,LeaveRequest,ReplacementRequest,Feedback,Payment]: admin.site.register(model)
